require(["./common"], function(common) {
	common(require("./a"));
});