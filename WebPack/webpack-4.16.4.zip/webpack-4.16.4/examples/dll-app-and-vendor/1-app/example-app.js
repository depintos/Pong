import { square } from "example-vendor";

console.log(square(7));
console.log(new square(7));
