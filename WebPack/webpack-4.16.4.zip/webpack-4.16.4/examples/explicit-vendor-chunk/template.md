# webpack.config.js

``` javascript
{{webpack.config.js}}
```

# dist/vendor.js

``` javascript
{{dist/vendor.js}}
```

# dist/pageA.js

``` javascript
{{dist/pageA.js}}
```

# Info

## Unoptimized

```
{{stdout}}
```

## Production mode

```
{{production:stdout}}
```
