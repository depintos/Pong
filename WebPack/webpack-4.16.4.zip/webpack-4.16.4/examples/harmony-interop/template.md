
# example.js

``` javascript
{{example.js}}
```

# fs.js

``` javascript
{{fs.js}}
```

# reexport-commonjs.js

``` javascript
{{reexport-commonjs.js}}
```

# example2.js

``` javascript
{{example2.js}}
```

# harmony.js

``` javascript
{{harmony.js}}
```

# dist/output.js

``` javascript
{{dist/output.js}}
```

# Info

## Unoptimized

```
{{stdout}}
```

## Production mode

```
{{production:stdout}}
```