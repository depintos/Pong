import { add } from './math';
import * as library from "./library";

add(1, 2);
library.reexportedMultiply(1, 2);
