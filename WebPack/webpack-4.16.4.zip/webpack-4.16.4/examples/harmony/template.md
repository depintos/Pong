
# example.js

``` javascript
{{example.js}}
```

# increment.js

``` javascript
{{increment.js}}
```

# dist/output.js

``` javascript
{{dist/output.js}}
```

# Info

## Unoptimized

```
{{stdout}}
```

## Production mode

```
{{production:stdout}}
```