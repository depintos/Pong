// Just show the page "a"
var render = require("./render");
render(require("./aPage"));