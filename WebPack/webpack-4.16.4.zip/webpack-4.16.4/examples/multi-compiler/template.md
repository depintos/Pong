
# example.js

``` javascript
{{example.js}}
```

# webpack.config.js

``` javascript
{{webpack.config.js}}
```

# dist/desktop.js

``` javascript
{{dist/desktop.js}}
```

# dist/mobile.js

``` javascript
{{dist/mobile.js}}
```

# Info

## Unoptimized

```
{{stdout}}
```

## Production mode

```
{{production:stdout}}
```