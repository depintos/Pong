var common = require("./common");
require(["./shared"], function(shared) {
	shared("This is page A");
});