var common = require("./common");
module.exports = function(msg) {
	console.log(msg);
};