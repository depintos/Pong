module.exports = "Vendor2";
require("./vendor1");
